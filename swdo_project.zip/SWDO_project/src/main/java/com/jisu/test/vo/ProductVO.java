package com.jisu.test.vo;

import lombok.Data;

@Data
public class ProductVO {
	
   private String openUri;
   private String productDisplayName;

}
