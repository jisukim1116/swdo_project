package com.swdo.test.vo;

import lombok.Data;

@Data
public class UserImageVO {
	
	private String originalFileName;
	private String savedFileName;
	private String savedFilePath;
}
